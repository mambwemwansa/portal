package zm.co.fnb.zra;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import zm.co.fnb.zra.model.LoginResponse;
import zm.co.fnb.zra.model.LookUpRequest;
import zm.co.fnb.zra.service.ZRAService;

@SpringBootApplication
@EnableScheduling
public class ZRAServiceApplication implements CommandLineRunner {
	Logger logger = LoggerFactory.getLogger(ZRAServiceApplication.class);

	@Autowired
	ZRAService service;
	static String ACCESS_TOKEN;

	public static void main(String[] args) {

		SpringApplication.run(ZRAServiceApplication.class, args);
	}

	@Scheduled(fixedRate = 10 * 1000)
	public void runKYCJOB() {
		
		boolean isactive = ACCESS_TOKEN.equals(service.login().getData().getAccesstoken());
		
		if(!isactive) {
			
			ACCESS_TOKEN = service.refreashToken(ACCESS_TOKEN).getData().getAccesstoken();
		}
		
		LookUpRequest lookup = new LookUpRequest();
		
		lookup.setLookupType("NRC");
		lookup.setLookupValue("302629641");
		service.kycLookUp(lookup);

	}

	@Override
	public void run(String... args) throws Exception {
		LoginResponse loginResponse = service.login();
		ACCESS_TOKEN = loginResponse.getData().getAccesstoken();

	}

}
