package zm.co.fnb.zra.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import zm.co.fnb.zra.model.LoginReqest;
import zm.co.fnb.zra.model.LoginResponse;
import zm.co.fnb.zra.model.LookUpRequest;
import zm.co.fnb.zra.model.LookUpResponse;
import zm.co.fnb.zra.model.RefreshTokenRequest;

@Service
public class ZRAService {
	Logger logger = LoggerFactory.getLogger(ZRAService.class);


	@Value("${zm.co.fnb.zra.service.LooUp_URL}")
	String LooUp_URL;
	
	
	@Value("${zm.co.fnb.zra.service.apiKey}")
	String apiKey;
	@Value("${zm.co.fnb.zra.service.username}")
	String username;
	@Value("${zm.co.fnb.zra.service.password}")
	String password;	
	@Value("${zm.co.fnb.zra.service.login_URL}")
	String login_URL;
	@Value("${zm.co.fnb.zra.service.refresh_URL}")
	String refresh_URL;

	LoginReqest login_request;
	LoginResponse login_reponse;
	
	

	public LookUpResponse kycLookUp(LookUpRequest lookupRequest) {
		
		Map<String, String> headers = new HashMap<>();
		headers.put("Content-Type", "application/json");
		headers.put("X-Api-Key", apiKey);

		ObjectMapper Obj = new ObjectMapper();
		String json_request;

		HttpResponse<String> response = null;
		try {
			json_request = Obj.writeValueAsString(lookupRequest);
			logger.info(json_request);

			response = Unirest.post(LooUp_URL).headers(headers).body(json_request).asString();
		} catch (UnirestException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info(String.valueOf(response.getStatus()));
		logger.info(response.getStatusText());
		logger.info(response.getBody().toString());
		Gson g = new Gson();
		LookUpResponse ws_response = g.fromJson(response.getBody().toString(), LookUpResponse.class);
		return ws_response;
	}



	public  LoginResponse refreashToken(String ACCESS_TOKEN) {

		Map<String, String> headers = new HashMap<>();
		headers.put("Content-Type", "application/json");
		headers.put("X-Api-Key", apiKey);
		
		RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
		refreshTokenRequest.setRefreshToken(ACCESS_TOKEN);
		
		ObjectMapper Obj = new ObjectMapper();
		String json_request = null;

		HttpResponse<JsonNode> response = null;
		try {
			json_request = Obj.writeValueAsString(refreshTokenRequest);
			logger.info(json_request);
			
			RequestConfig globalConfig = RequestConfig.custom()
					.setCookieSpec(CookieSpecs.IGNORE_COOKIES).build();
					        
					HttpClient httpclient = HttpClients.custom().setDefaultRequestConfig(globalConfig).build();
					Unirest.setHttpClient(httpclient);
			
			
			response = Unirest.post(refresh_URL).headers(headers).body(json_request).asJson();

		} catch (UnirestException | JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("REFRESH status: "+String.valueOf(response.getStatus()));
		logger.info("REFRESH text: "+response.getStatusText());
		logger.info("REFRESH body: "+response.getBody().toString());
		Gson g = new Gson();

		login_reponse = g.fromJson(response.getBody().toString(), LoginResponse.class);
		
		return login_reponse;

	}
	
	public  LoginResponse login() {
		
		Map<String, String> headers = new HashMap<>();
		headers.put("Content-Type", "application/json");
		headers.put("X-Api-Key", apiKey);
		
		login_request = new LoginReqest();
	    login_reponse = new LoginResponse();

		login_request.setUsername(username);
		login_request.setPassword(password);

		ObjectMapper Obj = new ObjectMapper();
		String json_request = null;

		HttpResponse<JsonNode> response = null;
		try {
			json_request = Obj.writeValueAsString(login_request);
			logger.info(json_request);
			
			RequestConfig globalConfig = RequestConfig.custom()
					.setCookieSpec(CookieSpecs.IGNORE_COOKIES).build();
					        
					HttpClient httpclient = HttpClients.custom().setDefaultRequestConfig(globalConfig).build();
					Unirest.setHttpClient(httpclient);
			
			
			response = Unirest.post(login_URL).headers(headers).body(json_request).asJson();

		} catch (UnirestException | JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("LOGIN status: "+String.valueOf(response.getStatus()));
		logger.info("LOGIN text: "+response.getStatusText());
		logger.info("LOGIN body: "+response.getBody().toString());
		Gson g = new Gson();

		login_reponse = g.fromJson(response.getBody().toString(), LoginResponse.class);
		
		return login_reponse;

	}

}
