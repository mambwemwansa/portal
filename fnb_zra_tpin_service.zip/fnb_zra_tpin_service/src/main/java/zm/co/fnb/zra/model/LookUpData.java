package zm.co.fnb.zra.model;

public class LookUpData {

}
