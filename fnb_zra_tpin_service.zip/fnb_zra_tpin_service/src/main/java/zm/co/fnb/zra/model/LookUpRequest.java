package zm.co.fnb.zra.model;

import org.springframework.stereotype.Component;

@Component
public class LookUpRequest {
	
	String lookupType;
	String lookupValue;
	
	
	public LookUpRequest() {
		super();
		// TODO Auto-generated constructor stub
	}


	public LookUpRequest(String lookupType, String lookupValue) {
		super();
		this.lookupType = lookupType;
		this.lookupValue = lookupValue;
	}


	public String getLookupType() {
		return lookupType;
	}


	public void setLookupType(String lookupType) {
		this.lookupType = lookupType;
	}


	public String getLookupValue() {
		return lookupValue;
	}


	public void setLookupValue(String lookupValue) {
		this.lookupValue = lookupValue;
	}


	@Override
	public String toString() {
		return "LookUpRequest [lookupType=" + lookupType + ", lookupValue=" + lookupValue + "]";
	}

		
}
