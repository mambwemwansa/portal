package zm.co.fnb.zra.model;

public class LookUPHeader {
	
	String service;
	String status;
	String errorCode;
	String errorMessage;
	
	
	public LookUPHeader() {
		super();
		// TODO Auto-generated constructor stub
	}


	public LookUPHeader(String service, String status, String errorCode, String errorMessage) {
		super();
		this.service = service;
		this.status = status;
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}


	public String getService() {
		return service;
	}


	public void setService(String service) {
		this.service = service;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getErrorCode() {
		return errorCode;
	}


	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}


	public String getErrorMessage() {
		return errorMessage;
	}


	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}


	@Override
	public String toString() {
		return "LookUPHeader [service=" + service + ", status=" + status + ", errorCode=" + errorCode
				+ ", errorMessage=" + errorMessage + "]";
	}
		
}
