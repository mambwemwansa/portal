package zm.co.zanaco.bill_master_schools.model;

public class ReportData {
	String report_name;
	String report_date_time;
	String report_user;
	String report_size;
	String report_download_url;
	
	public String getReport_name() {
		return report_name;
	}
	public void setReport_name(String report_name) {
		this.report_name = report_name;
	}
	public String getReport_date_time() {
		return report_date_time;
	}
	public void setReport_date_time(String report_date_time) {
		this.report_date_time = report_date_time;
	}
	public String getReport_user() {
		return report_user;
	}
	public void setReport_user(String report_user) {
		this.report_user = report_user;
	}
	public String getReport_download_url() {
		return report_download_url;
	}
	public void setReport_download_url(String report_download_url) {
		this.report_download_url = report_download_url;
	}
	public String getReport_size() {
		return report_size;
	}
	public void setReport_size(String report_size) {
		this.report_size = report_size;
	}
	
	
}
