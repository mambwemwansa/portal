package zm.co.zanaco.bill_master_schools.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import zm.co.zanaco.bill_master_schools.model.ReportData;
import zm.co.zanaco.bill_master_schools.model.UPTM_UTIL_CONSUMER_DETLS;
import zm.co.zanaco.bill_master_schools.service.MediaTypeUtils;
import zm.co.zanaco.bill_master_schools.service.UPTM_UTIL_CONSUMER_DETLSServiceImpl;

@Controller
@CrossOrigin(origins = "http://localhost:9093")
public class AppController {
	@Autowired
	UPTM_UTIL_CONSUMER_DETLSServiceImpl serviceRef;
	
    @Autowired
    private ServletContext servletContext;
	
	@Value("${zm.co.zanaco.ebop.reports_base_path}")
	private String reports_base_path;
	
	@Value("${zm.co.zanaco.ebop.upload_path}")
	private String upload_path;
	
	@GetMapping("/billmasterschools")
	public String index(Model model) {
		
		return "index"; // view
	}

	@GetMapping("/records")
	public String getAllMonthRecords(Model model) {
		List<UPTM_UTIL_CONSUMER_DETLS> recList = new ArrayList<UPTM_UTIL_CONSUMER_DETLS>();
		recList = serviceRef.getAllRecords();
	
		model.addAttribute("RecordsList", recList);
		return "records"; // view
	}
	
	@GetMapping("/reports")
	public String getAllReportsList(Model model) {
		List<ReportData> reportList = new ArrayList<ReportData>();
		reportList = serviceRef.getReportsList();
		model.addAttribute("ReprotsList", reportList);
		return "reports"; // view
	}
	
	@RequestMapping(value="/download")
	public ResponseEntity<InputStreamResource>  downloadFile(@Param(value="name") String name) {
	    
		SimpleDateFormat formatter = new SimpleDateFormat("MMMM"); 
		SimpleDateFormat yearformatter = new SimpleDateFormat("YYYY");
		String yearValue = yearformatter.format(new Date());

		String monthName = formatter.format(new Date());
	    String filePath = reports_base_path+"/"+yearValue+"/"+monthName+"/" + name;
	    

        MediaType mediaType = MediaTypeUtils.getMediaTypeForFileName(this.servletContext, name);
        
        System.out.println("fileName: " + name);
        System.out.println("mediaType: " + mediaType);
 
        File file = new File(filePath);
        InputStreamResource resource = null;
		try {
			resource = new InputStreamResource(new FileInputStream(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 
        return ResponseEntity.ok()
                // Content-Disposition
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName())
                // Content-Type
                .contentType(mediaType)
                // Contet-Length
                .contentLength(file.length()) //
                .body(resource);
	}
	
	@PostMapping("/upload")
    public String uploadFile(@RequestParam("file") MultipartFile file, RedirectAttributes attributes) {


		SimpleDateFormat dayformatter = new SimpleDateFormat("dd");
		SimpleDateFormat formatter = new SimpleDateFormat("MM"); 
		SimpleDateFormat yearformatter = new SimpleDateFormat("YYYY");
		
		String yearValue = yearformatter.format(new Date());
		String monthNumber = formatter.format(new Date());
		String dayNumber = dayformatter.format(new Date());
		
        // check if file is empty
        if (file.isEmpty()) {
            attributes.addFlashAttribute("failed_message", "Please select a file to upload.");
            return "redirect:/billmasterschools";
        }
        
        
        if (StringUtils.cleanPath(file.getOriginalFilename()).equals("BILLMASTSCH_"+yearValue+monthNumber+dayNumber+".csv")) {
			// normalize the file path
			String fileName = StringUtils.cleanPath(file.getOriginalFilename());
			// save the file on the local file system
			fileName = fileName.replace(".csv", "");
			String id = generateid();
			fileName = "BILLMASTSCH_" + yearValue + monthNumber + dayNumber + "_" + id+".csv";
			try {
				Path path = Paths.get(upload_path + "/" + fileName);
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException e) {
				e.printStackTrace();
			}
			// return success response
			attributes.addFlashAttribute("success_message",
					"You successfully uploaded " + fileName + ',' + "  Your Submission ID is :" + id );
		}else {
			attributes.addFlashAttribute("failed_message", "Invalid submission file.");
		}
		return "redirect:/billmasterschools";
    }

	
	// Generate id
	public  String generateid() {
		int randomPin   =(int)(Math.random()*9000)+1000;
		String otp  =String.valueOf(randomPin);
		return otp;
	}

}
