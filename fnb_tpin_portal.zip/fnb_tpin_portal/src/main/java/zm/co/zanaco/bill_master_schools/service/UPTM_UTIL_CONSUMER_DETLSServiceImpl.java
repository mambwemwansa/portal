package zm.co.zanaco.bill_master_schools.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import zm.co.zanaco.bill_master_schools.dao.ITranDAO;
import zm.co.zanaco.bill_master_schools.model.ReportData;
import zm.co.zanaco.bill_master_schools.model.UPTM_UTIL_CONSUMER_DETLS;

@Service
public class UPTM_UTIL_CONSUMER_DETLSServiceImpl implements ITRANService {

	@Autowired
	private ITranDAO daoRef;

	@Value("${zm.co.zanaco.ebop.reports_base_path}")
	private String reports_base_path;

	@Override
	public List<UPTM_UTIL_CONSUMER_DETLS> getAllRecords() {
		return daoRef.findUNZArecords();
	}

	@Override
	public List<ReportData> getReportsList() {
		List<ReportData> listList = new ArrayList<ReportData>();
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("MMMM");
			SimpleDateFormat yearformatter = new SimpleDateFormat("YYYY");
			String monthValue = formatter.format(new Date());
			String yearValue = yearformatter.format(new Date());
			File directory = new File(reports_base_path + "/" + yearValue + "/" + monthValue);
			// Get all the files from a directory.
			File[] fileList = directory.listFiles();
			if (fileList != null) {
				for (File file : fileList) {
					if (file.isFile()) {

						ReportData report = new ReportData();
						String file_name = file.getName();// REPORT NAME
						report.setReport_name(file_name);
						String datetime = getCreationDate(file.getAbsolutePath()); // DATE TIME
						report.setReport_date_time(datetime);
						String user = "Administrator";// USER
						report.setReport_user(user);
						report.setReport_size(file.length() / 1024 + "KB");// SIZE
						String download_text = "<a href=\"/download?filename=" + file.getName()
								+ "\" target=\"_top\">Download</a>";// DOWNLOAD URL
						report.setReport_download_url(download_text);

						listList.add(report);
					} else if (file.isDirectory()) {
					}
				}
			}

		} catch (Exception ex) {

		}
		return listList;
	}

	public String getCreationDate(String filepath) {

		File file = new File(filepath);
		String formatted = null;

		BasicFileAttributes attrs;
		try {
			attrs = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
			FileTime time = attrs.creationTime();

			String pattern = "yyyy-MM-dd HH:mm:ss";
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

			formatted = simpleDateFormat.format(new Date(time.toMillis()));

			System.out.println("The file creation date and time is: " + formatted);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return formatted;
	}


}
