package zm.co.zanaco.bill_master_schools;

import java.util.Locale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
public class StartBillMasterApplication {

	public static void main(String[] args) {
		
		Locale.setDefault(Locale.US);
		SpringApplication.run(StartBillMasterApplication.class, args);
	}

}
