package zm.co.zanaco.bill_master_schools.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import zm.co.zanaco.bill_master_schools.model.UPTM_UTIL_CONSUMER_DETLS;

@Repository
public interface ITranDAO extends JpaRepository<UPTM_UTIL_CONSUMER_DETLS, String> {
	
	@Query(value ="SELECT * FROM UPTM_UTIL_CONSUMER_DETLS WHERE  UTILITY_PROVIDER_ID ='6132-UNZA DRGS' AND NRC_NUMBER IS NOT NULL AND CONSUMER_NO IS NOT NULL AND CONSUMER_NAME IS NOT NULL AND UTILITY_PROVIDER_ID IS NOT NULL", nativeQuery=true)
	List<UPTM_UTIL_CONSUMER_DETLS> findUNZArecords();

}
