package zm.co.zanaco.bill_master_schools.service;

import java.util.List;

import zm.co.zanaco.bill_master_schools.model.ReportData;
import zm.co.zanaco.bill_master_schools.model.UPTM_UTIL_CONSUMER_DETLS;



public interface ITRANService {

	public List<UPTM_UTIL_CONSUMER_DETLS> getAllRecords();
	public List<ReportData> getReportsList();

}
