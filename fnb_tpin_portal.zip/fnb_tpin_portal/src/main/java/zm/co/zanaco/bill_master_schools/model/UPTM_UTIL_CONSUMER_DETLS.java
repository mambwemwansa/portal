package zm.co.zanaco.bill_master_schools.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "UPTM_UTIL_CONSUMER_DETLS")
public class UPTM_UTIL_CONSUMER_DETLS {

	@Column(name = "UTILITY_PROVIDER_ID",nullable = false)
	public String UTILITY_PROVIDER_ID ="NONE";
	@Column(name = "CONSUMER_NO",nullable = false)
	public String CONSUMER_NO="NONE";
	@Column(name = "CONSUMER_NAME",nullable = false)
	public String CONSUMER_NAME="NONE";
	@Id
	@Column(name = "NRC_NUMBER",nullable = false)
	public String NRC_NUMBER="NONE";
	
	

	public String getUTILITY_PROVIDER_ID() {
		return UTILITY_PROVIDER_ID;
	}

	public void setUTILITY_PROVIDER_ID(String uTILITY_PROVIDER_ID) {
		UTILITY_PROVIDER_ID = uTILITY_PROVIDER_ID;
	}

	public String getCONSUMER_NO() {
		return CONSUMER_NO;
	}

	public void setCONSUMER_NO(String cONSUMER_NO) {
		CONSUMER_NO = cONSUMER_NO;
	}

	public String getCONSUMER_NAME() {
		return CONSUMER_NAME;
	}

	public void setCONSUMER_NAME(String cONSUMER_NAME) {
		CONSUMER_NAME = cONSUMER_NAME;
	}

	public String getNRC_NUMBER() {
		return NRC_NUMBER;
	}

	public void setNRC_NUMBER(String nRC_NUMBER) {
		NRC_NUMBER = nRC_NUMBER;
	}

	public UPTM_UTIL_CONSUMER_DETLS(String uTILITY_PROVIDER_ID, String cONSUMER_NO, String cONSUMER_NAME,
			String nRC_NUMBER) {
		super();
		UTILITY_PROVIDER_ID = uTILITY_PROVIDER_ID;
		CONSUMER_NO = cONSUMER_NO;
		CONSUMER_NAME = cONSUMER_NAME;
		NRC_NUMBER = nRC_NUMBER;
	}

	public UPTM_UTIL_CONSUMER_DETLS() {
		super();
		// TODO Auto-generated constructor stub
	}

}
