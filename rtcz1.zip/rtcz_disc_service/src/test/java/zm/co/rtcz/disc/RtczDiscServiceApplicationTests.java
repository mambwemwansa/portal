package zm.co.rtcz.disc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtczDiscServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
