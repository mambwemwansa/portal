package zm.co.rtcz.appmgt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtczAppmgtServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
