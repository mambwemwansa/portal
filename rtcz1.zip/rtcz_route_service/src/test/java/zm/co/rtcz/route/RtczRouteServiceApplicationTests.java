package zm.co.rtcz.route;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtczRouteServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
