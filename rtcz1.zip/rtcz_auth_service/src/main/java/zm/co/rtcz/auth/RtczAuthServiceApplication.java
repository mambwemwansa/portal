package zm.co.rtcz.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RtczAuthServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RtczAuthServiceApplication.class, args);
	}

}
