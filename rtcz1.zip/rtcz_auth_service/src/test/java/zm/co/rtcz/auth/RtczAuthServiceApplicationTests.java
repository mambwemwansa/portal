package zm.co.rtcz.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtczAuthServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
